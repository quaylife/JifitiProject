//B)

internal class Program
{
    private static void Main(string[] args)
    {
        {
            "Age": "Twenty Five",
	"Height": 170,
	"Weight": 80,
	"Name": {
                "First": "Charles",
		"Last": "TheMock"

    },
	"HairColour": "Brown",
	"Address": {
                "City": "Kansas city",
		"Street": global::System.String v = "Blue street"; global::System.String v1 = """House"""; "547"

    },
	"MaritalStatus": "Single",
	"IsEmployed": true
}
    }
}