internal class Program
{
    private static void Main(string[] args)
    {
        That were sent to the following controller:

using Microsoft.AspNetCore.Mvc; using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Threading.Tasks;
}
}

namespace Professional.Services.Assignment