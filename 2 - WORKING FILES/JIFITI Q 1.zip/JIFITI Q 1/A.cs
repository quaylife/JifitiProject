//a

{
	"Age": 25,
	"Height": 170,
	"Weight": 80,
	"Name": {
		"First": "Charles",
		"Last":””
	},
	"HairColour": "Brown",
	"Address": {
		"City": "Kansas city",
		"Street": "Blue street",
		"House": "547"
	},
	"IsEmployed": true
}

